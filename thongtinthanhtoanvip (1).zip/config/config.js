//=========================================================//
var config_name = ['fullname', 'username','website','zalo','avatar','facebook'];
var config_aboutme = ['thathinh', 'chamngon'];
var config_stk = ['mbbank', 'momo','vietinbank','vietcombank'];
//=========================================================//
var set_1 = {
    fullname: 'Lương Đức Kiệt',
    username: 'DucKietDzz',
    website: 'hethongcheap.io.vn',
    zalo: '09750170xx',
    avatar: 'https://img.upanh.tv/2023/12/17/F1A4CED5-18E2-46AA-8EBE-97B5DD195562.png',
    facebook: 'https://fb.com/ad.duckietdz',
};
//=========================================================//
var set_2 = {
    thathinh: 'Anh không hoàn hảo, nhưng anh là duy nhất',
    chamngon: 'Là một người bình thường với sở thích hiểu công nghệ',
};
//=========================================================//
var set_3 = {
    mbbank: {
       sotaikhoan: '026620899999',
        chutaikhoan: 'LUONG DUC KIET',
    },
    momo: {
        sotaikhoan: '0975017051',
        chutaikhoan: 'LUONG DUC KIET',
    },
    vietinbank: {
        sotaikhoan: 'Đang cập nhật...',
        chutaikhoan: 'Đang cập nhật...',
    },
    vietcombank: {
        sotaikhoan: 'Đang cập nhật...',
        chutaikhoan: 'Đang cập nhật...',
    }
};
//=========================================================//